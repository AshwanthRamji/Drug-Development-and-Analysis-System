/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.ResearchRole;

import Business.Enterprise.Enterprise;
import Business.Initialization.Initialization;
import Business.Network.Network;
import Business.Organization.AnalysisOrganization;
import Business.Organization.ClinicalTestingOrganization;
import Business.Organization.HospitalOrganization;
import Business.Organization.ManufacturingOrganization;
import Business.Organization.Organization;
import Business.Organization.ResearchOrganization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.HospTestWorkRequest;
import Business.WorkQueue.HospitalWorkRequest;
import Business.WorkQueue.LabTestWorkRequest;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ashwa
 */
public class ResearchWorkAreaPanel extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private ResearchOrganization researchOrganization;
    private HospitalOrganization hospitalOrganization;
    private ClinicalTestingOrganization clinicalTestingOrganization;
    private Enterprise enterprise;
    private UserAccount userAccount;
    private ManufacturingOrganization organization;
    private Network network;

    /**
     * Creates new form ResearchWorkAreaPanel
     */
    public ResearchWorkAreaPanel(JPanel userProcessContainer, UserAccount account, ResearchOrganization researchOrganization, Enterprise enterprise) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.researchOrganization = researchOrganization;
        this.enterprise = enterprise;
        this.userAccount = account;
        // this.clinicalTestingOrganization = (ClinicalTestingOrganization) clinicalTestingOrganization;
        valueLabel.setText(enterprise.getName());
        populateRequestTable();
        populatePatientTable();

    }

    public void populateRequestTable() {
        DefaultTableModel model = (DefaultTableModel) workRequestJTable.getModel();

        model.setRowCount(0);
        for (WorkRequest request : researchOrganization.getWorkQueue().getWorkRequestList()) {
            if (request instanceof WorkRequest) {
                Object[] row = new Object[9];

                row[0] = request;
                row[1] = request.getDugAffectedPart();
                row[2] = request.getGeneOne();
                row[3] = request.getGeneTwo();
                //String result = ((LabTestWorkRequest) request).getTestResult();result == null ? "Waiting" : result;
                row[4] = request.getGeneThree();
                row[5] = request.getGeneFour();
                row[6] = request.getTotalCombination();
                row[7] = request.getDosage();
                String status = ((WorkRequest) request).getStatus();
                row[8] = status == null ? "Waiting" : status;
                //String manstatus = ((WorkRequest) request).getManStatus();
                //row[9] = manstatus == null ? "Null" : manstatus;

                model.addRow(row);
            }
        }
    }

    public void populatePatientTable() {
        String line = null;
        DefaultTableModel dtm = (DefaultTableModel) patientTable.getModel();
        dtm.setRowCount(0);
        for (HospitalWorkRequest request2 : Initialization.initializeworkList().getHospWorkRequestList()) {
            Object[] row = new Object[7];
            if (request2 instanceof HospitalWorkRequest) {
                row[0] = request2;
                row[1] = request2.getAffectedPart();
                row[2] = request2.getDiseaseDiag();
                row[3] = request2.getAssoGeneOne();
                row[4] = request2.getAssoGeneTwo();
                row[5] = request2.getAssoDrug();
                row[6] = request2.getAssoCombination();
                dtm.addRow(row);
            }
        }
        for (HospitalWorkRequest request2 : researchOrganization.getWorkQueue().getHospWorkRequestList()) {
            if (request2 instanceof HospitalWorkRequest) {
                Object[] row = new Object[8];
                row[0] = request2;
                row[1] = request2.getAffectedPart();
                row[2] = request2.getDiseaseDiag();
                row[3] = request2.getAssoGeneOne();
                row[4] = request2.getAssoGeneTwo();
                row[5] = request2.getAssoDrug();
                row[6] = request2.getAssoCombination();
                row[7] = request2.getDate();
                // row[6] = request2.getDrugComposition();
                dtm.addRow(row);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        enterpriseLabel = new javax.swing.JLabel();
        valueLabel = new javax.swing.JLabel();
        sendReportsJButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        compareButton = new javax.swing.JButton();
        drugresultTextField = new javax.swing.JTextField();
        compareCompoundsButton = new javax.swing.JButton();
        compareCompoundsTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        patientTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        workRequestJTable = new javax.swing.JTable();
        manuBtn = new javax.swing.JButton();
        createDrugJButton = new javax.swing.JButton();
        refreshTestJButton = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        enterpriseLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        enterpriseLabel.setForeground(new java.awt.Color(57, 128, 213));
        enterpriseLabel.setText("Enterprise :");

        valueLabel.setText("<value>");

        sendReportsJButton.setBackground(new java.awt.Color(255, 255, 255));
        sendReportsJButton.setText("SEND REPORTS TO CLINICAL LAB");
        sendReportsJButton.setEnabled(false);
        sendReportsJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendReportsJButtonActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe WP Semibold", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(57, 128, 213));
        jLabel2.setText("RESEARCH WORK AREA");

        compareButton.setBackground(new java.awt.Color(255, 255, 255));
        compareButton.setText("COMPARE GENE");
        compareButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compareButtonActionPerformed(evt);
            }
        });

        compareCompoundsButton.setBackground(new java.awt.Color(255, 255, 255));
        compareCompoundsButton.setText("COMPARE COMPOUNDS");
        compareCompoundsButton.setEnabled(false);
        compareCompoundsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compareCompoundsButtonActionPerformed(evt);
            }
        });

        compareCompoundsTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compareCompoundsTextFieldActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(57, 128, 213));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        patientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Patient ID", "Affected Area", "Disease", "Gene 1", "Gene 2", "Existing Drug", "Compounds"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(patientTable);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("PATIENT RECORDS");

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Send To Analysis");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        jPanel3.setBackground(new java.awt.Color(57, 128, 213));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        workRequestJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "DrugName", "Affected Part", "Gene 1", "Gene 2", "Gene 3", "Gene 4", "Compounds", "Dosage", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(workRequestJTable);

        manuBtn.setBackground(new java.awt.Color(255, 255, 255));
        manuBtn.setText("MANUFACTURE DRUG");
        manuBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manuBtnActionPerformed(evt);
            }
        });

        createDrugJButton.setBackground(new java.awt.Color(255, 255, 255));
        createDrugJButton.setText("CREATE DRUG");
        createDrugJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createDrugJButtonActionPerformed(evt);
            }
        });

        refreshTestJButton.setBackground(new java.awt.Color(255, 255, 255));
        refreshTestJButton.setText("Refresh");
        refreshTestJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshTestJButtonActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Send To Analysis");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(refreshTestJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(createDrugJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(manuBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshTestJButton)
                    .addComponent(createDrugJButton))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(manuBtn)
                    .addComponent(jButton2))
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(enterpriseLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(valueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(compareButton)
                                    .addGap(45, 45, 45)
                                    .addComponent(drugresultTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(28, 28, 28)
                                    .addComponent(compareCompoundsButton)
                                    .addGap(18, 18, 18)
                                    .addComponent(compareCompoundsTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(98, 98, 98)
                                    .addComponent(sendReportsJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(410, 410, 410)
                        .addComponent(jLabel2)))
                .addGap(0, 176, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(enterpriseLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(valueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(compareButton)
                    .addComponent(drugresultTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(compareCompoundsButton)
                    .addComponent(sendReportsJButton)
                    .addComponent(compareCompoundsTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(311, 311, 311))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void createDrugJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createDrugJButtonActionPerformed

        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        userProcessContainer.add("RequestClinicalTestJPanel", new RequestClinicalTestPanel(userProcessContainer, userAccount, researchOrganization, enterprise));
        layout.next(userProcessContainer);

        //LabTestWorkRequest request = (LabTestWorkRequest)workRequestJTable.getValueAt(selectedRow, 0);

    }//GEN-LAST:event_createDrugJButtonActionPerformed

    private void refreshTestJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshTestJButtonActionPerformed

        populateRequestTable();
    }//GEN-LAST:event_refreshTestJButtonActionPerformed

    private void manuBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manuBtnActionPerformed
        // TODO add your handling code here:

        int selectedRow = workRequestJTable.getSelectedRow();

        if (selectedRow >= 0) {
            WorkRequest request = (WorkRequest) workRequestJTable.getValueAt(selectedRow, 0);
            /*  if(request.getManStatus().equalsIgnoreCase("Manufactured")){
                JOptionPane.showMessageDialog(this,"Already Manufactured. Cannot be manufactured again");
                return;
            }*/
            try {
                if (request.getStatus().equalsIgnoreCase("Success")) {
                
                    //LabTestWorkRequest request = new LabTestWorkRequest();
                    //request.setTestDrugName(testDrugNameTextField.getText());
                    //request.setotalComboTextField.getText());

                    Organization org = null;
                    for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                        if (organization instanceof ManufacturingOrganization) {
                            org = organization;
                            break;
                        }
                    }
                    if (org != null) {
                        org.getWorkQueue().getWorkRequestList().add(request);
                        //userAccount.getWorkQueue().getWorkRequestList().add(request);
                    }
                    JOptionPane.showMessageDialog(this, "Sent to the Manufacturer");
                } else {
                    JOptionPane.showMessageDialog(this, "Not eligible for Manufacturing");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Select a success drug");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row");
            return;
        }

        //CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        //userProcessContainer.add("ManufacturerWorkAreaJPanel", new ManufacturerWorkAreaJPanel(userProcessContainer, userAccount, organization, enterprise, network));
        //layout.next(userProcessContainer);
    }//GEN-LAST:event_manuBtnActionPerformed

    private void sendReportsJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendReportsJButtonActionPerformed
        // TODO add your handling code here:

        int selectedRow = workRequestJTable.getSelectedRow();
        int selectedRow2 = patientTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow2 >= 0) {
            WorkRequest request = (WorkRequest) workRequestJTable.getValueAt(selectedRow, 0);
            request.setStatus("Sent");
            HospitalWorkRequest request2 = (HospitalWorkRequest) patientTable.getValueAt(selectedRow2, 0);
            Organization org = null;
            for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                if (organization instanceof ClinicalTestingOrganization) {
                    org = organization;
                    break;
                }
            }
            if (org != null) {
                org.getWorkQueue().getWorkRequestList().add(request);
                org.getWorkQueue().getHospWorkRequestList().add(request2);
                userAccount.getWorkQueue().getWorkRequestList().add(request);
                userAccount.getWorkQueue().getHospWorkRequestList().add(request2);
            }
            compareCompoundsButton.setEnabled(false);
            compareCompoundsTextField.setText("");
            drugresultTextField.setText("");
            JOptionPane.showMessageDialog(this, "Drug and Patient records sent for clinical testing");
            //  } else {
            // calcTextField.setText("unmatched");
            //   JOptionPane.showMessageDialog(this, "Cannot be Sent for Clinical Testing"); 
            //}
        } else {
            JOptionPane.showMessageDialog(this, "Select both rows");
        }
    }//GEN-LAST:event_sendReportsJButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int countHeart = 0;
        int countLiver = 0;
        int countKidney = 0;
        int countLung = 0;
        String userName = "ranbaxytest01";
        String password = "ranbaxytest@2";
        String sendingHost;
        int sendingPort;
        String from = "ranbaxytest01@gmail.com";
        String to;
        String subject;
        String text;
        String receivingHost;
        String newLine = System.getProperty("line.separator");//This will retrieve line separator dependent on OS.

        HospTestWorkRequest request = new HospTestWorkRequest();
        for (int j = 0; j < (patientTable.getRowCount()); j++) {
            if ((patientTable.getValueAt(j, 1).toString().equalsIgnoreCase("heart"))) {
                request.setValueHeart(++countHeart);
            }

            if ((patientTable.getValueAt(j, 1).toString().equalsIgnoreCase("lung"))) {
                request.setValueLung(++countLung);
            }
            if ((patientTable.getValueAt(j, 1).toString().equalsIgnoreCase("kidney"))) {
                request.setValueKidney(++countKidney);
            }
            if ((patientTable.getValueAt(j, 1).toString().equalsIgnoreCase("liver"))) {
                request.setValueLiver(++countLiver);
            }

            Organization org = null;
            for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                if (organization instanceof AnalysisOrganization) {
                    org = organization;
                    break;
                }
            }
            if (org != null) {
                org.getWorkQueue().getHospWorkRequestList().add(request);
                //userAccount.getWorkQueue().getWorkRequestList().add(request3);
            }
        }
        double sum = ((countLung) + (countLiver) + (countHeart) + (countKidney));
        double liverRatio = (countLiver) / sum;
        double lungRatio = (countLung) / sum;
        double heartRatio = (countHeart) / sum;
        double kidneyRatio = (countKidney) / sum;

        JOptionPane.showMessageDialog(this, "Data sent to analysis");
        Properties props = new Properties();

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", String.valueOf(465));
        props.put("mail.smtp.user", "ranbaxytest01");
        props.put("mail.smtp.password", "ranbaxytest@2");

        props.put("mail.smtp.auth", "true");

        Session session1 = Session.getDefaultInstance(props);

        Message simpleMessage = new MimeMessage(session1);

        //MIME stands for Multipurpose Internet Mail Extensions
        InternetAddress fromAddress = null;
        InternetAddress toAddress = null;

        try {

            fromAddress = new InternetAddress("ranbaxytest01@gmail.com");
            toAddress = new InternetAddress("biogentest00@gmail.com");

        } catch (AddressException e) {
            System.out.println("hello1");

            e.printStackTrace();

            JOptionPane.showMessageDialog(null, "Sending email is failed !!!", "Falied to Send!!!", JOptionPane.ERROR_MESSAGE);

        }

        try {

            simpleMessage.setFrom(fromAddress);

            simpleMessage.setRecipient(Message.RecipientType.TO, toAddress);

            // to add CC or BCC use
            // simpleMessage.setRecipient(RecipientType.CC, new InternetAddress("CC_Recipient@any_mail.com"));
            // simpleMessage.setRecipient(RecipientType.BCC, new InternetAddress("CBC_Recipient@any_mail.com"));
            simpleMessage.setSubject("Affected parts of patients");

            simpleMessage.setText("Patients affected by Heart Disease :" + (countHeart)
                    + newLine + "Patients affected by Lung Disease :" + (countLung)
                    + newLine + "Patients affected by Kidney Disease :" + (countKidney)
                    + newLine + "Patients affected by Liver Disease :" + (countLiver)
                    + newLine + "Ratio of Heart Disease :" + (heartRatio)
                    + newLine + "Ratio of Lung Disease :" + (lungRatio)
                    + newLine + "Ratio of Kidney Disease :" + (kidneyRatio)
                    + newLine + "Ratio of Liver Disease :" + (liverRatio));

            //sometimes Transport.send(simpleMessage); is used, but for gmail it's different
            Transport transport = session1.getTransport("smtps");

            transport.connect("smtp.gmail.com", 465, "ranbaxytest01@gmail.com", "ranbaxytest@2");

            transport.sendMessage(simpleMessage, simpleMessage.getAllRecipients());

            transport.close();

            JOptionPane.showMessageDialog(null, "Mail sent successfully ...", "Mail sent", JOptionPane.PLAIN_MESSAGE);

        } catch (MessagingException e) {
            System.out.println("fail");
            e.printStackTrace();

            JOptionPane.showMessageDialog(null, "Sending email to: is failed !!!", "Falied to Send!!!", JOptionPane.ERROR_MESSAGE);

        }

        /*this will print subject of all messages in the inbox of sender@gmail.com*/
        //this.receivingHost="imap.gmail.com";//for imap protocol
        Properties props2 = System.getProperties();

        props2.setProperty("mail.store.protocol", "imaps");
        // I used imaps protocol here

        Session session2 = Session.getDefaultInstance(props2, null);

        try {

            Store store = session2.getStore("imaps");

            store.connect("biogentest00@gmail.com", "ranbaxytest01@gmail.com", "ranbaxytest@2");

            Folder folder = store.getFolder("INBOX");//get inbox

            folder.open(Folder.READ_ONLY);//open folder only to read

            Message message[] = folder.getMessages();

            for (int i = 0; i < message.length; i++) {

                //print subjects of all mails in the inbox
                System.out.println(message[i].getSubject());

                //anything else you want
            }

            //close connections
            folder.close(true);

            store.close();

        } catch (Exception e) {

            System.out.println(e.toString());

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void compareButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compareButtonActionPerformed
        // TODO add your handling code here:for (WorkRequest request : userAccount.getWorkQueue().getWorkRequestList())
        int selectedRow = workRequestJTable.getSelectedRow();
        int selectedRow2 = patientTable.getSelectedRow();
        //  JOptionPane.showMessageDialog(null, "gene test");
        if (selectedRow >= 0 && selectedRow2 >= 0) {
            WorkRequest request = (WorkRequest) workRequestJTable.getValueAt(selectedRow, 0);
            HospitalWorkRequest request2 = (HospitalWorkRequest) patientTable.getValueAt(selectedRow2, 0);
            //for (WorkRequest request2 : researchOrganization.getWorkQueue().getWorkRequestList())
            //{
            // JOptionPane.showMessageDialog(null, "gene test");
            // for (int j = 0; j < (patientTable.getRowCount()); j++) {
            if ((request.getGeneOne()).equals(request2.getAssoGeneOne())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneOne()).equals(request2.getAssoGeneTwo())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneTwo()).equals(request2.getAssoGeneOne())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneTwo()).equals(request2.getAssoGeneTwo())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneThree()).equals(request2.getAssoGeneOne())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneThree()).equals(request2.getAssoGeneTwo())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneFour()).equals(request2.getAssoGeneOne())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else if ((request.getGeneFour()).equals(request2.getAssoGeneTwo())) {
                drugresultTextField.setText("Gene match");
                compareCompoundsButton.setEnabled(true);

            } else {
                drugresultTextField.setText("Gene unmatch");

            }
            //}
        } else {
            JOptionPane.showMessageDialog(this, "Select both rows");
        }
    }//GEN-LAST:event_compareButtonActionPerformed

    private void compareCompoundsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compareCompoundsButtonActionPerformed
        // TODO add your handling code here:
        int selectedRow = workRequestJTable.getSelectedRow();
        int selectedRow2 = patientTable.getSelectedRow();
        //  JOptionPane.showMessageDialog(null, "gene test");
        if (selectedRow >= 0 && selectedRow2 >= 0) {
            WorkRequest request = (WorkRequest) workRequestJTable.getValueAt(selectedRow, 0);
            HospitalWorkRequest request2 = (HospitalWorkRequest) patientTable.getValueAt(selectedRow2, 0);
            //for (WorkRequest request2 : researchOrganization.getWorkQueue().getWorkRequestList())
            //{
            // JOptionPane.showMessageDialog(null, "gene test");
            for (int j = 0; j < (patientTable.getRowCount()); j++) {
                if (request.getTotalCombination().toString().contains(request2.getAssoCombination().toString().toUpperCase())) {
                    compareCompoundsTextField.setText("Compounds match");
                    sendReportsJButton.setEnabled(true);

                    break;
                } else {
                    compareCompoundsTextField.setText("Compounds unmatch");

                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select both rows");
        }

    }//GEN-LAST:event_compareCompoundsButtonActionPerformed

    private void compareCompoundsTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compareCompoundsTextFieldActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_compareCompoundsTextFieldActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int successCount = 0;
        int failureCount = 0;
        String userName = "ranbaxytest00";
        String password = "ranbaxytest@1";
        String sendingHost;
        int sendingPort;
        String from = "ranbaxytest00@gmail.com";
        String to;
        String subject;
        String text;
        String receivingHost;
        String newLine = System.getProperty("line.separator");
        int ratio;
        LabTestWorkRequest request = new LabTestWorkRequest();
        for (int j = 0; j < (workRequestJTable.getRowCount()); j++) {
            if ((workRequestJTable.getValueAt(j, 8).toString().equalsIgnoreCase("Success"))) {
                request.setDrugSuccessCount(++successCount);
            }

            if ((workRequestJTable.getValueAt(j, 8).toString().equalsIgnoreCase("Failure"))) {
                request.setDrugFailureCount(++failureCount);
            }

            Organization org = null;
            for (Organization organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                if (organization instanceof AnalysisOrganization) {
                    org = organization;
                    break;
                }
            }
            if (org != null) {
                org.getWorkQueue().getWorkRequestList().add(request);
                //userAccount.getWorkQueue().getWorkRequestList().add(request3);
            }
        }
        double sum = ((successCount) + (failureCount));
        double successRatio = (successCount) / sum;
        double failureRatio = (failureCount) / sum;

        JOptionPane.showMessageDialog(this,
                "Data sent to analysis");

        // request.setResult(resultJTextField1.getText());
        // request.setStatus("Delivered");
        //this.userName=userName;//sender's email can also use as User Name
        //this.password=password;
        // This will send mail from -->sender@gmail.com to -->receiver@gmail.com
        //this.from=from;
        //this.to=toText.getText();
        //this.subject=subText.getText();
        //this.text=genText.getText();
        // For a Gmail account--sending mails-- host and port shold be as follows
        //this.sendingHost="smtp.gmail.com";
        //this.sendingPort=465;
        Properties props = new Properties();

        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", String.valueOf(465));
        props.put("mail.smtp.user", "ranbaxytest00");
        props.put("mail.smtp.password", "ranbaxytest@1");

        props.put("mail.smtp.auth", "true");

        Session session1 = Session.getDefaultInstance(props);

        Message simpleMessage = new MimeMessage(session1);

        //MIME stands for Multipurpose Internet Mail Extensions
        InternetAddress fromAddress = null;
        InternetAddress toAddress = null;

        try {

            fromAddress = new InternetAddress("ranbaxytest00@gmail.com");
            toAddress = new InternetAddress("biogentest00@gmail.com");

        } catch (AddressException e) {
            System.out.println("hello1");

            e.printStackTrace();

            JOptionPane.showMessageDialog(null, "Sending email is failed !!!", "Falied to Send!!!", JOptionPane.ERROR_MESSAGE);

        }

        try {

            simpleMessage.setFrom(fromAddress);

            simpleMessage.setRecipient(Message.RecipientType.TO, toAddress);

            // to add CC or BCC use
            // simpleMessage.setRecipient(RecipientType.CC, new InternetAddress("CC_Recipient@any_mail.com"));
            // simpleMessage.setRecipient(RecipientType.BCC, new InternetAddress("CBC_Recipient@any_mail.com"));
            simpleMessage.setSubject("Success and Failure count of Drugs :");

            simpleMessage.setText("Success count of Drugs :" + (successCount)
                    + newLine + "Failure count of Drugs :" + (failureCount)
                    + newLine + "Ratio of success :" + (successRatio)
                    + newLine + "Ratio of failure :" + (failureRatio));

            //sometimes Transport.send(simpleMessage); is used, but for gmail it's different
            Transport transport = session1.getTransport("smtps");

            transport.connect("smtp.gmail.com", 465, "ranbaxytest00@gmail.com", "ranbaxytest@1");

            transport.sendMessage(simpleMessage, simpleMessage.getAllRecipients());

            transport.close();

            JOptionPane.showMessageDialog(null, "Mail sent successfully ...", "Mail sent", JOptionPane.PLAIN_MESSAGE);

        } catch (MessagingException e) {
            System.out.println("fail");
            e.printStackTrace();

            JOptionPane.showMessageDialog(null, "Sending email to: is failed !!!", "Failed to Send!!!", JOptionPane.ERROR_MESSAGE);

        }

        /*this will print subject of all messages in the inbox of sender@gmail.com*/
        //this.receivingHost="imap.gmail.com";//for imap protocol
        Properties props2 = System.getProperties();

        props2.setProperty("mail.store.protocol", "imaps");
        // I used imaps protocol here

        Session session2 = Session.getDefaultInstance(props2, null);

        try {

            Store store = session2.getStore("imaps");

            store.connect("imap.gmail.com", "ranbaxytest00", "ranbaxytest@1");

            Folder folder = store.getFolder("INBOX");//get inbox

            folder.open(Folder.READ_ONLY);//open folder only to read

            Message message[] = folder.getMessages();

            for (int i = 0; i < message.length; i++) {

                //print subjects of all mails in the inbox
                System.out.println(message[i].getSubject());

                //anything else you want
            }

            //close connections
            folder.close(true);

            store.close();

        } catch (Exception e) {

            System.out.println(e.toString());

        }

    }//GEN-LAST:event_jButton2ActionPerformed

    /*  private void displayResearchTable(WorkRequest request) {
        testDrugNameTextField.setText(request.getTestDrugName());
        // compositionTextField.setText(request.getDrugComposition());
        resultTextField.setText(((LabTestWorkRequest) request).getTestResult());
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton compareButton;
    private javax.swing.JButton compareCompoundsButton;
    private javax.swing.JTextField compareCompoundsTextField;
    private javax.swing.JButton createDrugJButton;
    private javax.swing.JTextField drugresultTextField;
    private javax.swing.JLabel enterpriseLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton manuBtn;
    private javax.swing.JTable patientTable;
    private javax.swing.JButton refreshTestJButton;
    private javax.swing.JButton sendReportsJButton;
    private javax.swing.JLabel valueLabel;
    private javax.swing.JTable workRequestJTable;
    // End of variables declaration//GEN-END:variables
}
