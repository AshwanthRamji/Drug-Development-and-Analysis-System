/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Initialization;


import Business.WorkQueue.HospitalWorkRequest;
import Business.WorkQueue.WorkQueue;
import Business.WorkQueue.WorkRequest;

/**
 *
 * @author ashwa
 */
public class Initialization {
    public static WorkQueue initializeworkList() {
        WorkQueue queue = new WorkQueue();
        //HospitalWorkRequest hrequest = new HospitalWorkRequest() {};
       HospitalWorkRequest hrequest = queue.addHospWork();
        hrequest.setPatientID("1");
        hrequest.setPatientName("Renold");
        hrequest.setAge(12);
        hrequest.setAffectedPart("Heart");
        hrequest.setDiseaseDiag("Cardiomyopathies");
        //hrequest.setDate("04/21/2016");
        hrequest.setLabNo("6");
        hrequest.setBloodGroup("o+ve");
        hrequest.setBloodGluPostMeal(110);
        hrequest.setResrate(23);
        hrequest.setSex("male");
        hrequest.setHdlChol(180);
        hrequest.setBp(119);
        hrequest.setAssoDrug("Drug1");
        hrequest.setAssogoneCompOne("I");
        hrequest.setAssogoneCompTwo("J");
        hrequest.setAssogtwoCompOne("K");
        hrequest.setAssogtwoCompTwo("L");
        hrequest.setAssoCombination("IJKL");
        hrequest.setAssoGeneOne("Gene 5");
        hrequest.setAssoGeneTwo("Gene 6");
        
        
        HospitalWorkRequest hrequest2 = queue.addHospWork();
        hrequest2.setPatientID("2");
        hrequest2.setPatientName("Reyas");
        hrequest2.setAge(24);
        hrequest2.setAffectedPart("Heart");
        hrequest2.setDiseaseDiag("Cardiomyopathies");
        //hrequest2.setDate("04/28/2016");
        hrequest2.setLabNo("12");
        hrequest2.setBloodGroup("b+ve");
        hrequest2.setBloodGluPostMeal(165);
        hrequest2.setResrate(22);
        hrequest2.setSex("female");
        hrequest2.setHdlChol(185);
        hrequest2.setBp(40);
        hrequest2.setAssoDrug("Drug2");
        hrequest2.setAssogoneCompOne("I");
        hrequest2.setAssogoneCompTwo("J");
        hrequest2.setAssogtwoCompOne("K");
        hrequest2.setAssogtwoCompTwo("L");
        hrequest2.setAssoCombination("IJKL");
        hrequest2.setAssoGeneOne("Gene 7");
        hrequest2.setAssoGeneTwo("Gene 8");
        
        HospitalWorkRequest hrequest3 = queue.addHospWork();
        hrequest3.setPatientID("3");
        hrequest3.setPatientName("Rahul");
        hrequest3.setAge(36);
        hrequest3.setAffectedPart("Heart");
        hrequest3.setDiseaseDiag("Coronary Artery Disease");
        //hrequest3.setDate("04/18/2016");
        hrequest3.setLabNo("11");
        hrequest3.setBloodGroup("o-ve");
        hrequest3.setBloodGluPostMeal(130);
        hrequest3.setResrate(15);
        hrequest3.setSex("male");
        hrequest3.setHdlChol(240);
        hrequest3.setBp(55);
        hrequest3.setAssoDrug("Drug3");
        hrequest3.setAssogoneCompOne("M");
        hrequest3.setAssogoneCompTwo("N");
        hrequest3.setAssogtwoCompOne("O");
        hrequest3.setAssogtwoCompTwo("P");
        hrequest3.setAssoCombination("MNOP");
        hrequest3.setAssoGeneOne("Gene 5");
        hrequest3.setAssoGeneTwo("Gene 8");
       
        HospitalWorkRequest hrequest4 = queue.addHospWork();
        hrequest4.setPatientID("4");
        hrequest4.setPatientName("Ramya");
        hrequest4.setAge(48);
        hrequest4.setAffectedPart("Heart");
        hrequest4.setDiseaseDiag("Coronary Artery Disease");
        //hrequest4.setDate("04/25/2016");
        hrequest4.setLabNo("9");
        hrequest4.setBloodGroup("A+ve");
        hrequest4.setBloodGluPostMeal(140);
        hrequest4.setResrate(34);
        hrequest4.setSex("female");
        hrequest4.setHdlChol(160);
        hrequest4.setBp(90);
        hrequest4.setAssoDrug("Drug4");
        hrequest4.setAssogoneCompOne("M");
        hrequest4.setAssogoneCompTwo("N");
        hrequest4.setAssogtwoCompOne("O");
        hrequest4.setAssogtwoCompTwo("P");
        hrequest4.setAssoCombination("MNOP");
        hrequest4.setAssoGeneOne("Gene 6");
        hrequest4.setAssoGeneTwo("Gene 7");
       
        HospitalWorkRequest hrequest5 = queue.addHospWork();
        hrequest5.setPatientID("5");
        hrequest5.setPatientName("Rose");
        hrequest5.setAge(4);
        hrequest5.setAffectedPart("Heart");
        hrequest5.setDiseaseDiag("Coronary Artery Disease");
        //hrequest5.setDate("04/21/2016");
        hrequest5.setLabNo("13");
        hrequest5.setBloodGroup("o+ve");
        hrequest5.setBloodGluPostMeal(30);
        hrequest5.setResrate(1);
        hrequest5.setSex("male");
        hrequest5.setHdlChol(290);
        hrequest5.setBp(30);
        hrequest5.setAssoDrug("Drug5");
        hrequest5.setAssogoneCompOne("M");
        hrequest5.setAssogoneCompTwo("N");
        hrequest5.setAssogtwoCompOne("O");
        hrequest5.setAssogtwoCompTwo("P");
        hrequest5.setAssoCombination("MNOP");
        hrequest5.setAssoGeneOne("Gene 8");
        hrequest5.setAssoGeneTwo("Gene 5");
        
       // Lung Success case ( 4s 1f) 
        HospitalWorkRequest hrequest6 = queue.addHospWork();
        hrequest6.setPatientID("6");
        hrequest6.setPatientName("Rolland");
        hrequest6.setAge(36);
        hrequest6.setAffectedPart("Lung");
        hrequest6.setDiseaseDiag("Bronchitis");
        //hrequest.setDate("07/21/2016");
        hrequest6.setLabNo("9");
        hrequest6.setBloodGroup("a+ve");
        hrequest6.setBloodGluPostMeal(130);
        hrequest6.setResrate(15);
        hrequest6.setSex("male");
        hrequest6.setHdlChol(240);
        hrequest6.setBp(55);
        hrequest6.setAssoDrug("Drug6");
        hrequest6.setAssogoneCompOne("E");
        hrequest6.setAssogoneCompTwo("F");
        hrequest6.setAssogtwoCompOne("G");
        hrequest6.setAssogtwoCompTwo("H");
        hrequest6.setAssoCombination("EFGH");
        hrequest6.setAssoGeneOne("Gene 1");
        hrequest6.setAssoGeneTwo("Gene 2");
        
        
        HospitalWorkRequest hrequest7 = queue.addHospWork();
        hrequest7.setPatientID("7");
        hrequest7.setPatientName("hasan");
        hrequest7.setAge(20);
        hrequest7.setAffectedPart("Lung");
        hrequest7.setDiseaseDiag("Bronchitis");
        //hrequest2.setDate("09/28/2016");
        hrequest7.setLabNo("9");
        hrequest7.setBloodGroup("b+ve");
        hrequest7.setBloodGluPostMeal(145);
        hrequest7.setResrate(43);
        hrequest7.setSex("female");
        hrequest7.setHdlChol(250);
        hrequest7.setBp(30);
        hrequest7.setAssoDrug("Drug7");
        hrequest7.setAssogoneCompOne("E");
        hrequest7.setAssogoneCompTwo("F");
        hrequest7.setAssogtwoCompOne("G");
        hrequest7.setAssogtwoCompTwo("H");
        hrequest7.setAssoCombination("EFGH");
        hrequest7.setAssoGeneOne("Gene 2");
        hrequest7.setAssoGeneTwo("Gene 3");
        
        HospitalWorkRequest hrequest8 = queue.addHospWork();
        hrequest8.setPatientID("8");
        hrequest8.setPatientName("Rahulam");
        hrequest8.setAge(37);
        hrequest8.setAffectedPart("Lung");
        hrequest8.setDiseaseDiag("Asthma");
        //hrequest8.setDate("04/02/2016");
        hrequest8.setLabNo("4");
        hrequest8.setBloodGroup("o-ve");
        hrequest8.setBloodGluPostMeal(140);
        hrequest8.setResrate(34);
        hrequest8.setSex("male");
        hrequest8.setHdlChol(290);
        hrequest8.setBp(146);
        hrequest8.setAssoDrug("Drug8");
        hrequest8.setAssogoneCompOne("A");
        hrequest8.setAssogoneCompTwo("B");
        hrequest8.setAssogtwoCompOne("C");
        hrequest8.setAssogtwoCompTwo("D");
        hrequest8.setAssoCombination("ABCD");
        hrequest8.setAssoGeneOne("Gene 3");
        hrequest8.setAssoGeneTwo("Gene 2");
       
        HospitalWorkRequest hrequest9 = queue.addHospWork();
        hrequest9.setPatientID("9");
        hrequest9.setPatientName("Ramyavel");
        hrequest9.setAge(72);
        hrequest9.setAffectedPart("Lung");
        hrequest9.setDiseaseDiag("Lung cancer");
        //hrequest9.setDate("04/14/2016");
        hrequest9.setLabNo("6");
        hrequest9.setBloodGroup("A+ve");
        hrequest9.setBloodGluPostMeal(110);
        hrequest9.setResrate(18);
        hrequest9.setSex("female");
        hrequest9.setHdlChol(190);
        hrequest9.setBp(145);
        hrequest9.setAssoDrug("Drug9");
        hrequest9.setAssogoneCompOne("B");
        hrequest9.setAssogoneCompTwo("C");
        hrequest9.setAssogtwoCompOne("D");
        hrequest9.setAssogtwoCompTwo("E");
        hrequest9.setAssoCombination("BCDE");
        hrequest9.setAssoGeneOne("Gene 1");
        hrequest9.setAssoGeneTwo("Gene 2");
      
        HospitalWorkRequest hrequest10 = queue.addHospWork();
        hrequest10.setPatientID("10");
        hrequest10.setPatientName("lulla");
        hrequest10.setAge(8);
        hrequest10.setAffectedPart("Lung");
        hrequest10.setDiseaseDiag("Lung cancer");
        //hrequest10.setDate("03/21/2016");
        hrequest10.setLabNo("5");
        hrequest10.setBloodGroup("b-ve");
        hrequest10.setBloodGluPostMeal(30);
        hrequest10.setResrate(4);
        hrequest10.setSex("male");
        hrequest10.setHdlChol(290);
        hrequest10.setBp(30);
        hrequest10.setAssoDrug("Drug10");
        hrequest10.setAssogoneCompOne("B");
        hrequest10.setAssogoneCompTwo("C");
        hrequest10.setAssogtwoCompOne("D");
        hrequest10.setAssogtwoCompTwo("E");
        hrequest10.setAssoCombination("BCDE");
        hrequest10.setAssoGeneOne("Gene 1");
        hrequest10.setAssoGeneTwo("Gene 4");
        
        // kidney success case(4s 1f)
        HospitalWorkRequest hrequest11 = queue.addHospWork();
        hrequest11.setPatientID("11");
        hrequest11.setPatientName("kells");
        hrequest11.setAge(36);
        hrequest11.setAffectedPart("Kidney");
        hrequest11.setDiseaseDiag("Glomerulonephritis");
        //hrequest11.setDate("04/06/2016");
        hrequest11.setLabNo("9");
        hrequest11.setBloodGroup("o+ve");
        hrequest11.setBloodGluPostMeal(130);
        hrequest11.setResrate(15);
        hrequest11.setSex("male");
        hrequest11.setHdlChol(240);
        hrequest11.setBp(55);
        hrequest11.setAssoDrug("Drug11");
        hrequest11.setAssogoneCompOne("R");
        hrequest11.setAssogoneCompTwo("S");
        hrequest11.setAssogtwoCompOne("T");
        hrequest11.setAssogtwoCompTwo("U");
        hrequest11.setAssoCombination("RSTU");
        hrequest11.setAssoGeneOne("Gene 9");
        hrequest11.setAssoGeneTwo("Gene 10");
        
        
        HospitalWorkRequest hrequest12 = queue.addHospWork();
        hrequest12.setPatientID("12");
        hrequest12.setPatientName("relly");
        hrequest12.setAge(52);
        hrequest12.setAffectedPart("Kidney");
        hrequest12.setDiseaseDiag("Glomerulonephritis");
        //hrequest12.setDate("06/28/2016");
        hrequest12.setLabNo("4");
        hrequest12.setBloodGroup("b+ve");
        hrequest12.setBloodGluPostMeal(65);
        hrequest12.setResrate(27);
        hrequest12.setSex("female");
        hrequest12.setHdlChol(290);
        hrequest12.setBp(165);
        hrequest12.setAssoDrug("Drug12");
        hrequest12.setAssogoneCompOne("R");
        hrequest12.setAssogoneCompTwo("S");
        hrequest12.setAssogtwoCompOne("T");
        hrequest12.setAssogtwoCompTwo("U");
        hrequest12.setAssoCombination("RSTU");
        hrequest12.setAssoGeneOne("Gene 11");
        hrequest12.setAssoGeneTwo("Gene 12");
        
        HospitalWorkRequest hrequest13 = queue.addHospWork();
        hrequest13.setPatientID("13");
        hrequest13.setPatientName("Rahules");
        hrequest13.setAge(39);
        hrequest13.setAffectedPart("Kidney");
        hrequest13.setDiseaseDiag("Glomerulonephritis");
        //hrequest13.setDate("04/18/2016");
        hrequest13.setLabNo("5");
        hrequest13.setBloodGroup("o-ve");
        hrequest13.setBloodGluPostMeal(120);
        hrequest13.setResrate(110);
        hrequest13.setSex("male");
        hrequest13.setHdlChol(140);
        hrequest13.setBp(120);
        hrequest13.setAssoDrug("Drug13");
        hrequest13.setAssogoneCompOne("R");
        hrequest13.setAssogoneCompTwo("S");
        hrequest13.setAssogtwoCompOne("T");
        hrequest13.setAssogtwoCompTwo("U");
        hrequest13.setAssoCombination("RSTU");
        hrequest13.setAssoGeneOne("Gene 9");
        hrequest13.setAssoGeneTwo("Gene 10");
       
        HospitalWorkRequest hrequest14 = queue.addHospWork();
        hrequest14.setPatientID("14");
        hrequest14.setPatientName("Rouku");
        hrequest14.setAge(62);
        hrequest14.setAffectedPart("Heart");
        hrequest14.setDiseaseDiag("Coronary Artery Disease");
        //hrequest14.setDate("04/25/2016");
        hrequest14.setLabNo("6");
        hrequest14.setBloodGroup("A+ve");
        hrequest14.setBloodGluPostMeal(120);
        hrequest14.setResrate(110);
        hrequest14.setSex("female");
        hrequest14.setHdlChol(140);
        hrequest14.setBp(120);
        hrequest14.setAssoDrug("Drug14");
        hrequest14.setAssogoneCompOne("M");
        hrequest14.setAssogoneCompTwo("N");
        hrequest14.setAssogtwoCompOne("O");
        hrequest14.setAssogtwoCompTwo("P");
        hrequest14.setAssoCombination("MNOP");
        hrequest14.setAssoGeneOne("Gene 7");
        hrequest14.setAssoGeneTwo("Gene 6");
       
        HospitalWorkRequest hrequest15 = queue.addHospWork();
        hrequest15.setPatientID("15");
        hrequest15.setPatientName("Ramsey");
        hrequest15.setAge(80);
        hrequest15.setAffectedPart("Heart");
        hrequest15.setDiseaseDiag("Coronary Artery Disease");
        //hrequest15.setDate("04/21/2016");
        hrequest15.setLabNo("3");
        hrequest15.setBloodGroup("o+ve");
        hrequest15.setBloodGluPostMeal(120);
        hrequest15.setResrate(110);
        hrequest15.setSex("male");
        hrequest15.setHdlChol(140);
        hrequest15.setBp(120);
        hrequest15.setAssoDrug("Drug15");
        hrequest15.setAssogoneCompOne("M");
        hrequest15.setAssogoneCompTwo("N");
        hrequest15.setAssogtwoCompOne("O");
        hrequest15.setAssogtwoCompTwo("P");
        hrequest15.setAssoCombination("MNOP");
        hrequest15.setAssoGeneOne("Gene 8");
        hrequest15.setAssoGeneTwo("Gene 5");
        
       // liver success case ( 4s 1f) 
        HospitalWorkRequest hrequest16 = queue.addHospWork();
        hrequest16.setPatientID("16");
        hrequest16.setPatientName("Rekha");
        hrequest16.setAge(60);
        hrequest16.setAffectedPart("Liver");
        hrequest16.setDiseaseDiag("cirrohis");
        //hrequest16.setDate("05/21/2016");
        hrequest16.setLabNo("7");
        hrequest16.setBloodGroup("ab-ve");
        hrequest16.setBloodGluPostMeal(160);
        hrequest16.setResrate(18);
        hrequest16.setSex("male");
        hrequest16.setHdlChol(190);
        hrequest16.setBp(70);
        hrequest16.setAssoDrug("Drug16");
        hrequest16.setAssogoneCompOne("Y");
        hrequest16.setAssogoneCompTwo("Z");
        hrequest16.setAssogtwoCompOne("A1");
        hrequest16.setAssogtwoCompTwo("B1");
        hrequest16.setAssoCombination("YZA1B1");
        hrequest16.setAssoGeneOne("Gene 13");
        hrequest16.setAssoGeneTwo("Gene 15");
        
        
        HospitalWorkRequest hrequest17 = queue.addHospWork();
        hrequest17.setPatientID("17");
        hrequest17.setPatientName("Rula");
        hrequest17.setAge(52);
        hrequest17.setAffectedPart("Liver");
        hrequest17.setDiseaseDiag("cirrohis");
        //hrequest17.setDate("04/15/2016");
        hrequest17.setLabNo("1");
        hrequest17.setBloodGroup("ab+ve");
        hrequest17.setBloodGluPostMeal(65);
        hrequest17.setResrate(27);
        hrequest17.setSex("female");
        hrequest17.setHdlChol(290);
        hrequest17.setBp(165);
        hrequest17.setAssoDrug("Drug17");
        hrequest17.setAssogoneCompOne("Y");
        hrequest17.setAssogoneCompTwo("Z");
        hrequest17.setAssogtwoCompOne("A1");
        hrequest17.setAssogtwoCompTwo("B1");
        hrequest17.setAssoCombination("YZA1B1");
        hrequest17.setAssoGeneOne("Gene 13");
        hrequest17.setAssoGeneTwo("Gene 14");
        
        HospitalWorkRequest hrequest18 = queue.addHospWork();
        hrequest18.setPatientID("18");
        hrequest18.setPatientName("Rasoos");
        hrequest18.setAge(12);
        hrequest18.setAffectedPart("Liver");
        hrequest18.setDiseaseDiag("hemochromatosis");
        //hrequest18.setDate("07/18/2016");
        hrequest18.setLabNo("4");
        hrequest18.setBloodGroup("o+ve");
        hrequest18.setBloodGluPostMeal(110);
        hrequest18.setResrate(23);
        hrequest18.setSex("male");
        hrequest18.setHdlChol(180);
        hrequest18.setBp(119);
        hrequest18.setAssoDrug("Drug18");
        hrequest18.setAssogoneCompOne("C1");
        hrequest18.setAssogoneCompTwo("D1");
        hrequest18.setAssogtwoCompOne("E1");
        hrequest18.setAssogtwoCompTwo("F1");
        hrequest18.setAssoCombination("C1D1E1F1");
        hrequest18.setAssoGeneOne("Gene 15");
        hrequest18.setAssoGeneTwo("Gene 14");
       
        HospitalWorkRequest hrequest19 = queue.addHospWork();
        hrequest19.setPatientID("19");
        hrequest19.setPatientName("Rola");
        hrequest19.setAge(48);
        hrequest19.setAffectedPart("Liver");
        hrequest19.setDiseaseDiag("hemochromatosis");
        //hrequest19.setDate("06/25/2016");
        hrequest19.setLabNo("9");
        hrequest19.setBloodGroup("A+ve");
        hrequest19.setBloodGluPostMeal(140);
        hrequest19.setResrate(34);
        hrequest19.setSex("female");
        hrequest19.setHdlChol(160);
        hrequest19.setBp(90);
        hrequest19.setAssoDrug("Drug19");
        hrequest19.setAssogoneCompOne("C1");
        hrequest19.setAssogoneCompTwo("D1");
        hrequest19.setAssogtwoCompOne("E1");
        hrequest19.setAssogtwoCompTwo("F1");
        hrequest19.setAssoCombination("C1D1E1F1");
        hrequest19.setAssoGeneOne("Gene 14");
        hrequest19.setAssoGeneTwo("Gene 12");
       
        HospitalWorkRequest hrequest20 = queue.addHospWork();
        hrequest20.setPatientID("20");
        hrequest20.setPatientName("pablo");
        hrequest20.setAge(4);
        hrequest20.setAffectedPart("Liver");
        hrequest20.setDiseaseDiag("hepatitis");
        //hrequest20.setDate("01/20/2016");
        hrequest20.setLabNo("10");
        hrequest20.setBloodGroup("b+ve");
        hrequest20.setBloodGluPostMeal(30);
        hrequest20.setResrate(3);
        hrequest20.setSex("male");
        hrequest20.setHdlChol(290);
        hrequest20.setBp(30);
        hrequest20.setAssoDrug("Drug20");
        hrequest20.setAssogoneCompOne("Z");
        hrequest20.setAssogoneCompTwo("A1");
        hrequest20.setAssogtwoCompOne("B1");
        hrequest20.setAssogtwoCompTwo("C1");
        hrequest20.setAssoCombination("ZA1B1C1");
        hrequest20.setAssoGeneOne("Gene 13");
        hrequest20.setAssoGeneTwo("Gene 15");
        
        // heart failure and then dosage success( 3f 2s)
        HospitalWorkRequest hrequest21 = queue.addHospWork();
        hrequest21.setPatientID("21");
        hrequest21.setPatientName("lil");
        hrequest21.setAge(84);
        hrequest21.setAffectedPart("Heart");
        hrequest21.setDiseaseDiag("Cardiomyopathies");
        //hrequest21.setDate("04/29/2016");
        hrequest21.setLabNo("3");
        hrequest21.setBloodGroup("b+ve");
        hrequest21.setBloodGluPostMeal(80);
        hrequest21.setResrate(24);
        hrequest21.setSex("male");
        hrequest21.setHdlChol(160);
        hrequest21.setBp(135);
        hrequest21.setAssoDrug("Drug21");
        hrequest21.setAssogoneCompOne("I");
        hrequest21.setAssogoneCompTwo("J");
        hrequest21.setAssogtwoCompOne("K");
        hrequest21.setAssogtwoCompTwo("L");
        hrequest21.setAssoCombination("IJKL");
        hrequest21.setAssoGeneOne("Gene 8");
        hrequest21.setAssoGeneTwo("Gene 5");
        
        
        HospitalWorkRequest hrequest22 = queue.addHospWork();
        hrequest22.setPatientID("22");
        hrequest22.setPatientName("gera");
        hrequest22.setAge(48);
        hrequest22.setAffectedPart("Heart");
        hrequest22.setDiseaseDiag("Coronary Artery Disease");
        //hrequest22.setDate("03/28/2016");
        hrequest22.setLabNo("4");
        hrequest22.setBloodGroup("ab+ve");
        hrequest22.setBloodGluPostMeal(140);
        hrequest22.setResrate(34);
        hrequest22.setSex("female");
        hrequest22.setHdlChol(160);
        hrequest22.setBp(90);
        hrequest22.setAssoDrug("Drug22");
        hrequest22.setAssogoneCompOne("M");
        hrequest22.setAssogoneCompTwo("N");
        hrequest22.setAssogtwoCompOne("O");
        hrequest22.setAssogtwoCompTwo("P");
        hrequest22.setAssoCombination("MNOP");
        hrequest22.setAssoGeneOne("Gene 6");
        hrequest22.setAssoGeneTwo("Gene 5");
        
        HospitalWorkRequest hrequest23 = queue.addHospWork();
        hrequest23.setPatientID("23");
        hrequest23.setPatientName("riti");
        hrequest23.setAge(61);
        hrequest23.setAffectedPart("Heart");
        hrequest23.setDiseaseDiag("Cardiomyopathies");
        //hrequest23.setDate("04/18/2016");
        hrequest23.setLabNo("5");
        hrequest23.setBloodGroup("o-ve");
        hrequest23.setBloodGluPostMeal(180);
        hrequest23.setResrate(2);
        hrequest23.setSex("male");
        hrequest23.setHdlChol(320);
        hrequest23.setBp(175);
        hrequest23.setAssoDrug("Drug23");
        hrequest23.setAssogoneCompOne("I");
        hrequest23.setAssogoneCompTwo("J");
        hrequest23.setAssogtwoCompOne("K");
        hrequest23.setAssogtwoCompTwo("L");
        hrequest23.setAssoCombination("IJKL");
        hrequest23.setAssoGeneOne("Gene 6");
        hrequest23.setAssoGeneTwo("Gene 8");
       
        HospitalWorkRequest hrequest24 = queue.addHospWork();
        hrequest24.setPatientID("24");
        hrequest24.setPatientName("Ramyala");
        hrequest24.setAge(81);
        hrequest24.setAffectedPart("Heart");
        hrequest24.setDiseaseDiag("Coronary Artery Disease");
        //hrequest24.setDate("04/25/2016");
        hrequest24.setLabNo("6");
        hrequest24.setBloodGroup("A+ve");
        hrequest24.setBloodGluPostMeal(175);
        hrequest24.setResrate(42);
        hrequest24.setSex("female");
        hrequest24.setHdlChol(250);
        hrequest24.setBp(57);
        hrequest24.setAssoDrug("Drug24");
        hrequest24.setAssogoneCompOne("M");
        hrequest24.setAssogoneCompTwo("N");
        hrequest24.setAssogtwoCompOne("O");
        hrequest24.setAssogtwoCompTwo("P");
        hrequest24.setAssoCombination("MNOP");
        hrequest24.setAssoGeneOne("Gene 7");
        hrequest24.setAssoGeneTwo("Gene 5");
       
        HospitalWorkRequest hrequest25 = queue.addHospWork();
        hrequest25.setPatientID("25");
        hrequest25.setPatientName("lyla");
        hrequest25.setAge(5);
        hrequest25.setAffectedPart("Heart");
        hrequest25.setDiseaseDiag("Coronary Artery Disease");
        //hrequest25.setDate("02/21/2016");
        hrequest25.setLabNo("3");
        hrequest25.setBloodGroup("a-ve");
        hrequest25.setBloodGluPostMeal(30);
        hrequest25.setResrate(2);
        hrequest25.setSex("male");
        hrequest25.setHdlChol(299);
        hrequest25.setBp(30);
        hrequest25.setAssoDrug("Drug25");
        hrequest25.setAssogoneCompOne("M");
        hrequest25.setAssogoneCompTwo("N");
        hrequest25.setAssogtwoCompOne("O");
        hrequest25.setAssogtwoCompTwo("P");
        hrequest25.setAssoCombination("MNOP");
        hrequest25.setAssoGeneOne("Gene 7");
        hrequest25.setAssoGeneTwo("Gene 8");
        
        
        // lung failure and then dosage success( 3f 2s)
        HospitalWorkRequest hrequest26 = queue.addHospWork();
        hrequest26.setPatientID("26");
        hrequest26.setPatientName("Renoldus");
        hrequest26.setAge(37);
        hrequest26.setAffectedPart("Lung");
        hrequest26.setDiseaseDiag("Bronchitis");
        //hrequest26.setDate("04/08/2016");
        hrequest26.setLabNo("3");
        hrequest26.setBloodGroup("o-ve");
        hrequest26.setBloodGluPostMeal(140);
        hrequest26.setResrate(37);
        hrequest26.setSex("male");
        hrequest26.setHdlChol(290);
        hrequest26.setBp(146);
        hrequest26.setAssoDrug("Drug26");
        hrequest26.setAssogoneCompOne("E");
        hrequest26.setAssogoneCompTwo("F");
        hrequest26.setAssogtwoCompOne("G");
        hrequest26.setAssogtwoCompTwo("H");
        hrequest26.setAssoCombination("EFGH");
        hrequest26.setAssoGeneOne("Gene 4");
        hrequest26.setAssoGeneTwo("Gene 2");
        
        
        HospitalWorkRequest hrequest27 = queue.addHospWork();
        hrequest27.setPatientID("27");
        hrequest27.setPatientName("Reyask");
        hrequest27.setAge(52);
        hrequest27.setAffectedPart("Lung");
        hrequest27.setDiseaseDiag("Bronchitis");
        //hrequest27.setDate("04/04/2016");
        hrequest27.setLabNo("4");
        hrequest27.setBloodGroup("b-ve");
        hrequest27.setBloodGluPostMeal(65);
        hrequest27.setResrate(27);
        hrequest27.setSex("female");
        hrequest27.setHdlChol(290);
        hrequest27.setBp(165);
        hrequest27.setAssoDrug("Drug27");
        hrequest27.setAssogoneCompOne("E");
        hrequest27.setAssogoneCompTwo("F");
        hrequest27.setAssogtwoCompOne("G");
        hrequest27.setAssogtwoCompTwo("H");
        hrequest27.setAssoCombination("EFGH");
        hrequest27.setAssoGeneOne("Gene 1");
        hrequest27.setAssoGeneTwo("Gene 3");
        
        HospitalWorkRequest hrequest28 = queue.addHospWork();
        hrequest28.setPatientID("28");
        hrequest28.setPatientName("Rahulos");
        hrequest28.setAge(63);
        hrequest28.setAffectedPart("Lung");
        hrequest28.setDiseaseDiag("Lung infection");
        //hrequest28.setDate("05/18/2016");
        hrequest28.setLabNo("5");
        hrequest28.setBloodGroup("ab-ve");
        hrequest28.setBloodGluPostMeal(40);
        hrequest28.setResrate(4);
        hrequest28.setSex("male");
        hrequest28.setHdlChol(39);
        hrequest28.setBp(190);
        hrequest28.setAssoDrug("Drug28");
        hrequest28.setAssogoneCompOne("D");
        hrequest28.setAssogoneCompTwo("E");
        hrequest28.setAssogtwoCompOne("F");
        hrequest28.setAssogtwoCompTwo("G");
        hrequest28.setAssoCombination("DEFG");
        hrequest28.setAssoGeneOne("Gene 1");
        hrequest28.setAssoGeneTwo("Gene 4");
       
        HospitalWorkRequest hrequest29 = queue.addHospWork();
        hrequest29.setPatientID("29");
        hrequest29.setPatientName("Ramya");
        hrequest29.setAge(87);
        hrequest29.setAffectedPart("Lung");
        hrequest29.setDiseaseDiag("Lung infection");
        //hrequest29.setDate("05/25/2016");
        hrequest29.setLabNo("6");
        hrequest29.setBloodGroup("ab+ve");
        hrequest29.setBloodGluPostMeal(175);
        hrequest29.setResrate(42);
        hrequest29.setSex("female");
        hrequest29.setHdlChol(250);
        hrequest29.setBp(57);
        hrequest29.setAssoDrug("Drug29");
        hrequest29.setAssogoneCompOne("D");
        hrequest29.setAssogoneCompTwo("E");
        hrequest29.setAssogtwoCompOne("F");
        hrequest29.setAssogtwoCompTwo("G");
        hrequest29.setAssoCombination("DEFG");
        hrequest29.setAssoGeneOne("Gene 1");
        hrequest29.setAssoGeneTwo("Gene 2");
       
        HospitalWorkRequest hrequest30 = queue.addHospWork();
        hrequest30.setPatientID("30");
        hrequest30.setPatientName("Rosea");
        hrequest30.setAge(4);
        hrequest30.setAffectedPart("Lung");
        hrequest30.setDiseaseDiag("Lung Asthma");
        //hrequest30.setDate("04/30/2016");
        hrequest30.setLabNo("3");
        hrequest30.setBloodGroup("b+ve");
        hrequest30.setBloodGluPostMeal(30);
        hrequest30.setResrate(1);
        hrequest30.setSex("male");
        hrequest30.setHdlChol(290);
        hrequest30.setBp(30);
        hrequest30.setAssoDrug("Drug30");
        hrequest30.setAssogoneCompOne("A");
        hrequest30.setAssogoneCompTwo("B");
        hrequest30.setAssogtwoCompOne("C");
        hrequest30.setAssogtwoCompTwo("D");
        hrequest30.setAssoCombination("ABCD");
        hrequest30.setAssoGeneOne("Gene 3");
        hrequest30.setAssoGeneTwo("Gene 2");
        /*
        CompoundWorkRequest wrequest = queue.addCompWork();
        wrequest.setComp("A");
        wrequest.setFormula("C2H4O");
        
        CompoundWorkRequest wrequest2 = queue.addCompWork();
        wrequest2.setComp("B");
        wrequest2.setFormula("C2H5N0");
        
        CompoundWorkRequest wrequest3 = queue.addCompWork();
        wrequest3.setComp("C");
        wrequest3.setFormula("CH3COOH");
        
        CompoundWorkRequest wrequest4 = queue.addCompWork();
        wrequest4.setComp("D");
        wrequest4.setFormula("C3H60");
        
        CompoundWorkRequest wrequest5 = queue.addCompWork();
        wrequest5.setComp("E");
        wrequest5.setFormula("C2H3N");
        
        CompoundWorkRequest wrequest6 = queue.addCompWork();
        wrequest6.setComp("F");
        wrequest6.setFormula("ALCL3");
        
        CompoundWorkRequest wrequest7 = queue.addCompWork();
        wrequest7.setComp("G");
        wrequest7.setFormula("NH3");
        
        CompoundWorkRequest wrequest8 = queue.addCompWork();
        wrequest8.setComp("H");
        wrequest8.setFormula("CH3COONH4");
        
        CompoundWorkRequest wrequest9 = queue.addCompWork();
        wrequest9.setComp("I");
        wrequest9.setFormula("NH4CL");
        
        CompoundWorkRequest wrequest10 = queue.addCompWork();
        wrequest10.setComp("J");
        wrequest10.setFormula("NH4OH");
        
        CompoundWorkRequest wrequest11 = queue.addCompWork();
        wrequest11.setComp("K");
        wrequest11.setFormula("NH4NO3");
        
        CompoundWorkRequest wrequest12 = queue.addCompWork();
        wrequest12.setComp("L");
        wrequest12.setFormula("SBCL3");
        
        CompoundWorkRequest wrequest13 = queue.addCompWork();
        wrequest13.setComp("M");
        wrequest13.setFormula("SBCL5");
        
        CompoundWorkRequest wrequest14 = queue.addCompWork();
        wrequest14.setComp("N");
        wrequest14.setFormula("BACL2");
        
        CompoundWorkRequest wrequest15 = queue.addCompWork();
        wrequest15.setComp("O");
        wrequest15.setFormula("BICL3");
        
        CompoundWorkRequest wrequest16 = queue.addCompWork();
        wrequest16.setComp("P");
        wrequest16.setFormula("C4H10O");
        
        CompoundWorkRequest wrequest17 = queue.addCompWork();
        wrequest17.setComp("Q");
        wrequest17.setFormula("C6H8O");
        
        CompoundWorkRequest wrequest18 = queue.addCompWork();
        wrequest18.setComp("R");
        wrequest18.setFormula("COSO4");
        
        CompoundWorkRequest wrequest19 = queue.addCompWork();
        wrequest19.setComp("S");
        wrequest19.setFormula("CU2CL2");
        
        CompoundWorkRequest wrequest20 = queue.addCompWork();
        wrequest20.setComp("T");
        wrequest20.setFormula("CUCL2");
        
        CompoundWorkRequest wrequest21 = queue.addCompWork();
        wrequest21.setComp("U");
        wrequest21.setFormula("CUSO4");
        
        CompoundWorkRequest wrequest22 = queue.addCompWork();
        wrequest22.setComp("V");
        wrequest22.setFormula("CH20");
        
        CompoundWorkRequest wrequest23 = queue.addCompWork();
        wrequest23.setComp("W");
        wrequest23.setFormula("C2H5OH");
        
        CompoundWorkRequest wrequest24 = queue.addCompWork();
        wrequest24.setComp("X");
        wrequest24.setFormula("CH2O2");
        
        CompoundWorkRequest wrequest25 = queue.addCompWork();
        wrequest25.setComp("Y");
        wrequest25.setFormula("CDSO4");
        
        CompoundWorkRequest wrequest26 = queue.addCompWork();
        wrequest26.setComp("Z");
        wrequest26.setFormula("CACL2");
        
        CompoundWorkRequest wrequest27 = queue.addCompWork();
        wrequest27.setComp("A1");
        wrequest27.setFormula("C4H802");
        
        CompoundWorkRequest wrequest28 = queue.addCompWork();
        wrequest28.setComp("B1");
        wrequest28.setFormula("CASO4");
        
        CompoundWorkRequest wrequest29 = queue.addCompWork();
        wrequest29.setComp("C1");
        wrequest29.setFormula("CS2");
        
        CompoundWorkRequest wrequest30 = queue.addCompWork();
        wrequest30.setComp("D1");
        wrequest30.setFormula("CHCL3");
        
        CompoundWorkRequest wrequest31 = queue.addCompWork();
        wrequest31.setComp("E1");
        wrequest31.setFormula("CRCL3");
        
        CompoundWorkRequest wrequest32 = queue.addCompWork();
        wrequest32.setComp("F1");
        wrequest32.setFormula("CRO3");
       */ 
        return queue;
    }
}
