/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.UserAccount.UserAccount;
import java.util.Date;

/**
 *
 * @author raunak
 */
public abstract class WorkRequest {

    private String message;
    private String name;
    private String manStatus;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private Date requestDate;
    private Date resolveDate;
    private String drugName;
    private String drugComposition;
    private int quantity;
    private int price;
    private String dugAffectedPart;
    private String goneCompOne;
    private String goneCompTwo;
    private String gtwoCompOne;
    private String gtwoCompTwo;
    private String gthreeCompOne;
    private String gthreeCompTwo;
    private String gfourCompOne;
    private String gfourCompTwo;
    private String geneOne;
    private String geneTwo;
    private String geneThree;
    private String geneFour;
    private String compounds;
    private String testDrugName;
    private String combination;
    private String totalCombination;
    private String addlCompounds;
    private Integer drugSuccessCount;
    private Integer drugFailureCount;
    private Integer dosage;
   
    
    public Integer getDosage() {
        return dosage;
    }

    public void setDosage(Integer dosage) {
        this.dosage = dosage;
    }
    
    public Integer getDrugFailureCount() {
        return drugFailureCount;
    }

    public void setDrugFailureCount(Integer drugFailureCount) {
        this.drugFailureCount = drugFailureCount;
    }
    
    public Integer getDrugSuccessCount() {
        return drugSuccessCount;
    }

    public void setDrugSuccessCount(Integer drugSuccessCount) {
        this.drugSuccessCount = drugSuccessCount;
    }
    
    public String getManStatus() {
        return manStatus;
    }

    public void setManStatus(String manStatus) {
        this.manStatus = manStatus;
    }

    public String getDugAffectedPart() {
        return dugAffectedPart;
    }

    public void setDugAffectedPart(String dugAffectedPart) {
        this.dugAffectedPart = dugAffectedPart;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getDrugComposition() {
        return drugComposition;
    }

    public void setDrugComposition(String drugComposition) {
        this.drugComposition = drugComposition;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getGoneCompOne() {
        return goneCompOne;
    }

    public void setGoneCompOne(String goneCompOne) {
        this.goneCompOne = goneCompOne;
    }

    public String getGoneCompTwo() {
        return goneCompTwo;
    }

    public void setGoneCompTwo(String goneCompTwo) {
        this.goneCompTwo = goneCompTwo;
    }

    public String getGtwoCompOne() {
        return gtwoCompOne;
    }

    public void setGtwoCompOne(String gtwoCompOne) {
        this.gtwoCompOne = gtwoCompOne;
    }

    public String getGtwoCompTwo() {
        return gtwoCompTwo;
    }

    public void setGtwoCompTwo(String gtwoCompTwo) {
        this.gtwoCompTwo = gtwoCompTwo;
    }

    public String getGthreeCompOne() {
        return gthreeCompOne;
    }

    public void setGthreeCompOne(String gthreeCompOne) {
        this.gthreeCompOne = gthreeCompOne;
    }

    public String getGthreeCompTwo() {
        return gthreeCompTwo;
    }

    public void setGthreeCompTwo(String gthreeCompTwo) {
        this.gthreeCompTwo = gthreeCompTwo;
    }

    public String getGfourCompOne() {
        return gfourCompOne;
    }

    public void setGfourCompOne(String gfourCompOne) {
        this.gfourCompOne = gfourCompOne;
    }

    public String getGfourCompTwo() {
        return gfourCompTwo;
    }

    public void setGfourCompTwo(String gfourCompTwo) {
        this.gfourCompTwo = gfourCompTwo;
    }

    public String getGeneOne() {
        return geneOne;
    }

    public void setGeneOne(String geneOne) {
        this.geneOne = geneOne;
    }

    public String getGeneTwo() {
        return geneTwo;
    }

    public void setGeneTwo(String geneTwo) {
        this.geneTwo = geneTwo;
    }

    public String getGeneThree() {
        return geneThree;
    }

    public void setGeneThree(String geneThree) {
        this.geneThree = geneThree;
    }

    public String getGeneFour() {
        return geneFour;
    }

    public void setGeneFour(String geneFour) {
        this.geneFour = geneFour;
    }

    public String getCompounds() {
        return compounds;
    }

    public void setCompounds(String compounds) {
        this.compounds = compounds;
    }

    public String getTestDrugName() {
        return testDrugName;
    }

    public void setTestDrugName(String testDrugName) {
        this.testDrugName = testDrugName;
    }

    public String getCombination() {
        return combination;
    }

    public void setCombination(String combination) {
        this.combination = combination;
    }

    public String getTotalCombination() {
        return totalCombination;
    }

    public void setTotalCombination(String totalCombination) {
        this.totalCombination = totalCombination;
    }

    public String getAddlCompounds() {
        return addlCompounds;
    }

    public void setAddlCompounds(String addlCompounds) {
        this.addlCompounds = addlCompounds;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
