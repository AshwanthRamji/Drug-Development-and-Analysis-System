/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author ashwa
 */
public class WorkQueue {
   
    private ArrayList<WorkRequest> workRequestList;
    private ArrayList<HospitalWorkRequest> hospWorkRequestList;
    private ArrayList<LogisticsWorkRequest> logWorkRequestList;
    public WorkQueue() {
        
      workRequestList = new ArrayList<WorkRequest>();  
      hospWorkRequestList= new ArrayList<HospitalWorkRequest>();
      logWorkRequestList = new ArrayList<LogisticsWorkRequest>();
      
    }

    public ArrayList<LogisticsWorkRequest> getLogWorkRequestList() {
        return logWorkRequestList;
    }

    public void setLogWorkRequestList(ArrayList<LogisticsWorkRequest> logWorkRequestList) {
        this.logWorkRequestList = logWorkRequestList;
    }

    public ArrayList<HospitalWorkRequest> getHospWorkRequestList() {
        return hospWorkRequestList;
    }

    public ArrayList<WorkRequest> getWorkRequestList() {
        return workRequestList;
    }
       public LogisticsWorkRequest addLogWork(){
          LogisticsWorkRequest l = new LogisticsWorkRequest() {};
      logWorkRequestList.add(l);
       return l;
     } 
     public HospitalWorkRequest addHospWork(){
          HospitalWorkRequest h = new HospitalWorkRequest() {};
      hospWorkRequestList.add(h);
       return h;
     }
     public WorkRequest addWork(){
      WorkRequest w = new WorkRequest() {};
      workRequestList.add(w);
       return w;
   }
}
