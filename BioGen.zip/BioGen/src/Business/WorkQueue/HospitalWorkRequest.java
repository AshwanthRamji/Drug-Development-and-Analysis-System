/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.Date;

/**
 *
 * @author ashwa
 */
public abstract class HospitalWorkRequest {

    private String patientID;
    private String patientName;
    private String sex;
    private String referredBy;
    //private String date;
    private String labNo;
    private String visitNo;
    private String bloodGroup;
    private int resrate;
    private int bloodGluPostMeal;
    private int hdlChol;
    private int bp;
    private String affectedPart;
    private String diseaseDiag;
    private String assoGeneOne;
    private String assoGeneTwo;
    private String assoDrug;
    private String assogoneCompOne;
    private String assogoneCompTwo;
    private String assogtwoCompOne;
    private String assogtwoCompTwo;
    private int age;
    private String assoCombination;
    private Integer lungCount;
    private Integer heartCount;
    private Integer liverCount;
    private Integer kidneyCount;
    private Integer valueLung;
    private Integer valueHeart;
    private Integer valueKidney;
    private Integer valueLiver;
    private Date date;
    
    public Integer getValueLung() {
        return valueLung;
    }

    public void setValueLung(Integer valueLung) {
        this.valueLung = valueLung;
    }

    public Integer getValueHeart() {
        return valueHeart;
    }

    public void setValueHeart(Integer valueHeart) {
        this.valueHeart = valueHeart;
    }

    public Integer getValueKidney() {
        return valueKidney;
    }

    public void setValueKidney(Integer valueKidney) {
        this.valueKidney = valueKidney;
    }

    public Integer getValueLiver() {
        return valueLiver;
    }

    public void setValueLiver(Integer valueLiver) {
        this.valueLiver = valueLiver;
    }
    public Integer getLungCount() {
        return lungCount;
    }

    public void setLungCount(Integer lungCount) {
        this.lungCount = lungCount;
    }

    public Integer getHeartCount() {
        return heartCount;
    }

    public void setHeartCount(Integer heartCount) {
        this.heartCount = heartCount;
    }

    public Integer getLiverCount() {
        return liverCount;
    }

    public void setLiverCount(Integer liverCount) {
        this.liverCount = liverCount;
    }

    public Integer getKidneyCount() {
        return kidneyCount;
    }

    public void setKidneyCount(Integer kidneyCount) {
        this.kidneyCount = kidneyCount;
    }
    public int getHdlChol() {
        return hdlChol;
    }

    public void setHdlChol(int hdlChol) {
        this.hdlChol = hdlChol;
    }

    public int getBp() {
        return bp;
    }

    public void setBp(int bp) {
        this.bp = bp;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    public String getAssoCombination() {
        return assoCombination;
    }

    public void setAssoCombination(String assoCombination) {
        this.assoCombination = assoCombination;
    }

    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getReferredBy() {
        return referredBy;
    }

    public void setReferredBy(String referredBy) {
        this.referredBy = referredBy;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLabNo() {
        return labNo;
    }

    public void setLabNo(String labNo) {
        this.labNo = labNo;
    }

    public String getVisitNo() {
        return visitNo;
    }

    public void setVisitNo(String visitNo) {
        this.visitNo = visitNo;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public int getResrate() {
        return resrate;
    }

    public void setResrate(int resrate) {
        this.resrate = resrate;
    }

    public int getBloodGluPostMeal() {
        return bloodGluPostMeal;
    }

    public void setBloodGluPostMeal(int bloodGluPostMeal) {
        this.bloodGluPostMeal = bloodGluPostMeal;
    }

    

    public String getAffectedPart() {
        return affectedPart;
    }

    public void setAffectedPart(String affectedPart) {
        this.affectedPart = affectedPart;
    }

    public String getDiseaseDiag() {
        return diseaseDiag;
    }

    public void setDiseaseDiag(String diseaseDiag) {
        this.diseaseDiag = diseaseDiag;
    }

    public String getAssoGeneOne() {
        return assoGeneOne;
    }

    public void setAssoGeneOne(String assoGeneOne) {
        this.assoGeneOne = assoGeneOne;
    }

    public String getAssoGeneTwo() {
        return assoGeneTwo;
    }

    public void setAssoGeneTwo(String assoGeneTwo) {
        this.assoGeneTwo = assoGeneTwo;
    }

    public String getAssoDrug() {
        return assoDrug;
    }

    public void setAssoDrug(String assoDrug) {
        this.assoDrug = assoDrug;
    }

    public String getAssogoneCompOne() {
        return assogoneCompOne;
    }

    public void setAssogoneCompOne(String assogoneCompOne) {
        this.assogoneCompOne = assogoneCompOne;
    }

    public String getAssogoneCompTwo() {
        return assogoneCompTwo;
    }

    public void setAssogoneCompTwo(String assogoneCompTwo) {
        this.assogoneCompTwo = assogoneCompTwo;
    }

    public String getAssogtwoCompOne() {
        return assogtwoCompOne;
    }

    public void setAssogtwoCompOne(String assogtwoCompOne) {
        this.assogtwoCompOne = assogtwoCompOne;
    }

    public String getAssogtwoCompTwo() {
        return assogtwoCompTwo;
    }

    public void setAssogtwoCompTwo(String assogtwoCompTwo) {
        this.assogtwoCompTwo = assogtwoCompTwo;
    }

    @Override
    public String toString() {
        return this.patientID;
    }
}
