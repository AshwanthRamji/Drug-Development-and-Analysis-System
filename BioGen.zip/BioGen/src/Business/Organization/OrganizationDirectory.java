/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.Research.getValue())){
            organization = new ResearchOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Manufacturing.getValue())){
            organization = new ManufacturingOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.ClinicalTesting.getValue())){
            organization = new ClinicalTestingOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Analysis.getValue())){
           organization = new AnalysisOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Logistics.getValue())){
            organization = new LogisticsOrganization();
            organizationList.add(organization);
        }
       else if (type.getValue().equals(Type.Hospital.getValue())){
           organization = new HospitalOrganization();
           organizationList.add(organization);
        }
         else if (type.getValue().equals(Type.LogisticsAnalysis.getValue())){
           organization = new LogisticsAnalysisOrganization();
           organizationList.add(organization);
        }
        return organization;
    }
}