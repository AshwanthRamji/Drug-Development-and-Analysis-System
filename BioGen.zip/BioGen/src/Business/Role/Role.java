/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
//import Business.LogisticsOrganization.LOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkQueue;
import Business.WorkQueue.WorkRequest;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public abstract class Role {
    
    public enum RoleType{
        Admin("Admin"),
        Research("Research and Development"),Clinical("Clinical Testing"),
        Manufacturing("Manufacturing"),Analysis("Analysis"),Logistics("Logistics"),Hospital("Hospital"),LogisticsAnalysisRole("LogisticsAnalysisRole");
        
        
        private String value;
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccount account, 
            Organization organization, 
            Enterprise enterprise, Network network,
            EcoSystem business);
    
  //  public abstract JPanel createWorkAreaLog (JPanel userProcessContainer, 
    //        UserAccount account, 
      //      LogisticsOrganization logisticsOrganization, 
        //    Enterprise enterprise,
          //  EcoSystem business);

    @Override
    public String toString() {
        return this.getClass().getName();
    }
    
    
}