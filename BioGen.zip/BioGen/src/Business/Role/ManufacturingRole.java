/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
//import Business.LogisticsOrganization.LOrganization;
//import Business.LogisticsOrganization.LogisticsOrganization;
import Business.Organization.ManufacturingOrganization;
import Business.Organization.ResearchOrganization;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkQueue;
import userinterface.MaunfacturingRole.ManufacturerWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class ManufacturingRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization,Enterprise enterprise,Network network,EcoSystem business) {
        return new ManufacturerWorkAreaJPanel(userProcessContainer, account, (ManufacturingOrganization)organization, enterprise,network);
    }
    
    
}
