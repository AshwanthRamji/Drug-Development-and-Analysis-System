/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.LogisticsOrganization;
//import Business.LogisticsOrganization.LOrganization;
import Business.Organization.Organization;
//import Business.LogisticsOrganization.LogisticsOrganization;
//import Business.LogisticsOrganization.Organization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkQueue;
import userinterface.LogisticsRole.LogisticsWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class LogisticsRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization,Enterprise enterprise,Network network,EcoSystem business) {
        return new LogisticsWorkAreaJPanel(userProcessContainer, account, (LogisticsOrganization)organization,enterprise, business);
    }
    
}
